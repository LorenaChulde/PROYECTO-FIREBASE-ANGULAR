export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDE4AMSiYkWrU-DicwLdNPHHwVFZqvP7ms",
    authDomain: "listaritems-46c15.firebaseapp.com",
    databaseURL: "https://listaritems-46c15.firebaseio.com",
    projectId: "listaritems-46c15",
    storageBucket: "listaritems-46c15.appspot.com",
    messagingSenderId: "154185642981"
  }
};
